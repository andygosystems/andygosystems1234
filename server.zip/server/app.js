const express = require('express');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { exec } = require('child_process');
const compression = require('compression');
const helmet = require('helmet');
const cors = require('cors');
const morgan = require('morgan');
const mysql = require('mysql2/promise');

const app = express();
const PORT = process.env.PORT || 3000;
const FRONTEND_DIR = process.env.FRONTEND_DIR || path.resolve(__dirname, '../dist');
const UPLOADS_DIR = process.env.UPLOADS_DIR || path.resolve(__dirname, '../public/uploads');

const dbPool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB_NAME,
  charset: 'utf8mb4_unicode_ci',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

const logDir = path.resolve(__dirname, '../logs');
if (!fs.existsSync(logDir)) fs.mkdirSync(logDir, { recursive: true });
const accessLogStream = fs.createWriteStream(path.join(logDir, 'production.log'), { flags: 'a' });

app.use(express.json({ limit: '100mb' }));
app.use(compression());
app.use(helmet());
app.use(morgan('combined', { stream: accessLogStream }));

const allowedOrigins = (process.env.CORS_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean);
app.use(cors({
  origin: function (origin, callback) {
    if (!origin || allowedOrigins.includes(origin)) return callback(null, true);
    return callback(new Error('Not allowed by CORS'));
  },
  credentials: true,
}));

app.get('/api/health', async (req, res) => {
  let dbOk = false;
  let uploadsWritable = false;
  let memory = { total: os.totalmem(), free: os.freemem() };
  let disk = { total: null, used: null, free: null };
  try {
    const conn = await dbPool.getConnection();
    await conn.query('SELECT 1');
    conn.release();
    dbOk = true;
  } catch (e) {}
  try {
    if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR, { recursive: true });
    const testFile = path.join(UPLOADS_DIR, `.writetest_${Date.now()}`);
    fs.writeFileSync(testFile, 'ok');
    fs.unlinkSync(testFile);
    uploadsWritable = true;
  } catch (e) {}
  try {
    exec('df -Pk', (err, stdout) => {
      if (!err && stdout) {
        const lines = stdout.trim().split('\n');
        const parts = lines[lines.length - 1].split(/\s+/);
        disk.total = parseInt(parts[1], 10) * 1024;
        disk.used = parseInt(parts[2], 10) * 1024;
        disk.free = parseInt(parts[3], 10) * 1024;
      }
      res.json({ db: dbOk, uploadsWritable, memory, disk });
    });
  } catch (e) {
    res.json({ db: dbOk, uploadsWritable, memory, disk });
  }
});

app.post('/api/sync-status', async (req, res) => {
  const urls = Array.isArray(req.body?.urls) ? req.body.urls : [];
  const results = [];
  for (const u of urls) {
    try {
      const controller = new AbortController();
      const t = setTimeout(() => controller.abort(), 8000);
      const r = await fetch(u, { method: 'HEAD', signal: controller.signal });
      clearTimeout(t);
      results.push({ url: u, ok: r.ok, status: r.status });
    } catch (e) {
      results.push({ url: u, ok: false });
    }
  }
  res.json({ items: results });
});

app.post('/api/import', async (req, res) => {
  const items = Array.isArray(req.body?.items) ? req.body.items : [];
  const conn = await dbPool.getConnection();
  try {
    await conn.beginTransaction();
    for (const it of items) {
      const title = it.title || 'Untitled';
      const description = it.description || '';
      const price = Number(it.price || 0);
      const currency = it.currency || 'KES';
      const location = it.location || '';
      const type = it.type === 'Rent' ? 'Rent' : 'Sale';
      const status = it.status || 'available';
      const bedrooms = Number(it.bedrooms || 0);
      const bathrooms = Number(it.bathrooms || 0);
      const sqm = Number(it.sqm || 0);
      const lat = it.lat ?? null;
      const lng = it.lng ?? null;
      const property_type = it.property_type || null;
      const virtual_tour_url = it.virtual_tour_url || null;
      const images = Array.isArray(it.images) ? it.images : [];
      const amenities = Array.isArray(it.amenities) ? it.amenities : [];
      const keywords = Array.isArray(it.keywords) ? it.keywords.map(s => String(s).toLowerCase()) : [];
      const land_category = it.land_category || null;
      const tenure_type = it.tenure_type || null;
      const plot_size = it.plot_size || null;
      const doc_ready_title = keywords.some(k => k.includes('title')) ? 1 : 0;
      const doc_allotment_letter = keywords.some(k => k.includes('allotment')) ? 1 : 0;
      const doc_search_conducted = keywords.some(k => k.includes('search')) ? 1 : 0;
      const invest_fenced = keywords.some(k => k.includes('gated') || k.includes('fenced')) ? 1 : 0;
      const invest_beacons = keywords.some(k => k.includes('beacons')) ? 1 : 0;
      const invest_borehole = keywords.some(k => k.includes('borehole')) ? 1 : 0;
      const invest_electricity = keywords.some(k => k.includes('electricity')) ? 1 : 0;
      const proximity_near_main_road = keywords.some(k => k.includes('main road')) ? 1 : 0;
      const proximity_distance_cbd = it.proximity_distance_cbd ?? null;
      const proximity_future_infra = keywords.some(k => k.includes('bypass') || k.includes('future')) ? 1 : 0;
      const topography = it.topography || null;
      const payment_plan = it.payment_plan || null;
      const verified_listing = it.verified_listing ? 1 : 0;
      const [ins] = await conn.execute(
        'INSERT INTO properties (title, description, price, currency, location, type, status, bedrooms, bathrooms, sqm, lat, lng, property_type, virtual_tour_url, land_category, tenure_type, plot_size, doc_ready_title, doc_allotment_letter, doc_search_conducted, invest_fenced, invest_beacons, invest_borehole, invest_electricity, proximity_near_main_road, proximity_distance_cbd, proximity_future_infra, topography, payment_plan, verified_listing, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW(),NOW())',
        [title, description, price, currency, location, type, status, bedrooms, bathrooms, sqm, lat, lng, property_type, virtual_tour_url, land_category, tenure_type, plot_size, doc_ready_title, doc_allotment_letter, doc_search_conducted, invest_fenced, invest_beacons, invest_borehole, invest_electricity, proximity_near_main_road, proximity_distance_cbd, proximity_future_infra, topography, payment_plan, verified_listing]
      );
      const pid = ins.insertId;
      for (let i = 0; i < images.length; i++) {
        await conn.execute('INSERT INTO property_images (property_id, url, is_primary) VALUES (?,?,?)', [pid, images[i], i === 0 ? 1 : 0]);
      }
      for (const a of amenities) {
        await conn.execute('INSERT INTO property_amenities (property_id, name) VALUES (?,?)', [pid, a]);
      }
    }
    await conn.commit();
    res.status(201).json({ imported: items.length });
  } catch (e) {
    await conn.rollback();
    accessLogStream.write(`IMPORT_ERROR ${e.message}\n`);
    res.status(500).json({ error: 'import_failed' });
  } finally {
    conn.release();
  }
});

app.use('/api', (req, res) => {
  res.status(404).json({ error: 'not_found' });
});

app.use(express.static(FRONTEND_DIR));
app.get('*', (req, res) => {
  res.sendFile(path.join(FRONTEND_DIR, 'index.html'));
});

app.use((err, req, res, next) => {
  accessLogStream.write(`ERROR ${err.message}\n`);
  res.status(500).json({ error: 'server_error' });
});

app.listen(PORT, () => {});
